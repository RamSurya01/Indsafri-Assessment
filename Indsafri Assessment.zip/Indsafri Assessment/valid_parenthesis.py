def check_valid(string: str) -> bool:
    stack = []
    dictionary = {
        ")": "(",
        "}": "{",
        "]": "["
    }

    for c in string:
        if c in dictionary:
            if not stack or dictionary[c] != stack.pop():
                return False
        else:
            stack.append(c)

    return not stack


print(check_valid('{[{[([])]}]}'))
