import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.model_selection import train_test_split

import pickle


df = pd.read_csv('data.csv', names=['review', 'sentiment'], skiprows=1)
df = df[['review', 'sentiment']].dropna()

texts = df['review'].astype(str).values
labels = df['sentiment'].map({'positive': 1, 'negative': 0, 'neutral': 0}).values


vocab_size = 500
max_len = 20
tokenizer = Tokenizer(num_words=vocab_size, oov_token="<OOV>")
tokenizer.fit_on_texts(texts)

tokenizer_path = "tokenizer.pkl"
with open(tokenizer_path, 'wb') as file:
    pickle.dump(tokenizer, file)


sequences = tokenizer.texts_to_sequences(texts)
padded = pad_sequences(sequences, maxlen=max_len)

x_train, x_test, y_train, y_test = train_test_split(padded, labels, test_size=0.25, random_state=11)

model = Sequential()
model.add(Embedding(vocab_size, 64, input_length=max_len))
model.add(LSTM(32))
model.add(Dense(1, activation='sigmoid'))

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
model.summary()

model.fit(x_train, y_train, epochs=50, batch_size=31, validation_split=0.2)

loss, accuracy = model.evaluate(x_test, y_test)
print(f"Test Accuracy: {accuracy * 100:.2f}%")

model_path = f"lstm_sentiment_model_{int(accuracy * 100)}.pkl"
with open(model_path, 'wb') as file:
    pickle.dump(model, file)

print(f"Model Saved : {model_path}")
