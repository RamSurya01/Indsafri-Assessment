from tensorflow.keras.preprocessing.sequence import pad_sequences
import pickle

vocab_size = 500
max_len = 20

def predict_sentiment(text, modell) -> str:
    tokenizer = pickle.load(open("tokenizer.pkl", "rb"))
    seq = tokenizer.texts_to_sequences([text])
    print("seq", seq)
    padded_seq = pad_sequences(seq, maxlen=max_len)
    prediction = modell.predict(padded_seq)[0][0]
    return "positive" if prediction >= 0.5 else "negative"


with open("lstm_sentiment_model_81.pkl", 'rb') as file:
    model = pickle.load(file)

tweets = ["I loved the movies", "It can be improved a lot"]
print("Reviews and Sentiments")
for i in tweets:
    print(f"{i} - {predict_sentiment(i, model)}")