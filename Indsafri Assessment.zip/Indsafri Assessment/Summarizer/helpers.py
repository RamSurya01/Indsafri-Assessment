import requests
from pypdf import PdfReader
import docx


def read_pdf(file_path) -> str:
    reader = PdfReader(file_path)
    extracted_text = ""
    for page_no in range(len(reader.pages)):
        extracted_text += reader.pages[page_no].extract_text()

    return extracted_text


def read_doc(file_path) -> str:
    document = docx.Document(file_path)
    full_text = []
    for paragraph in document.paragraphs:
        full_text.append(paragraph.text)
    return '\n'.join(full_text)


def read_book(file_path: str, filename: str):
    extension = filename.rsplit(".", 1)[1].lower()

    if extension == "pdf":
        return read_pdf(file_path)

    elif extension == "docx" or extension == "doc":
        return read_doc(file_path)

    return ""


def hf_summarizer(text : str) -> str:
    api_url = "https://router.huggingface.co/hf-inference/models/Falconsai/text_summarization"
    headers = {
        "Authorization": f"Bearer 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",
    }

    def query(payload):
        response = requests.post(api_url, headers=headers, json=payload)
        return response.json()

    output = query({
        "inputs": text})

    if isinstance(output, list):
        return output[0]["summary_text"]

    return output

hf_summarizer("12")